package ru.mirea.gibo03.lab1;
import java.util.*;
import java.lang.System;

public class HelloJava {
    public static void main(String[] args) {
        System.out.println("Hello Java");
    }
}
